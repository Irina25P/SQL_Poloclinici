package Repository;

public class AutentificareRepository {
}
